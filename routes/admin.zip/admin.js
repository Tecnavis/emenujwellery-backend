
// var express = require('express')
// var router = express.Router()
// var multer = require('multer');
// var storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, 'public/images');
//   },
//   filename: function (req, file, cb) {
//     cb(null, Date.now() + '-' + file.originalname);
//   },
// });

// var upload = multer({ dest: 'uploads/' });


var express = require('express')
var router = express.Router()
const multer = require('multer');

// Configure storage options
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/images'); // Ensure this directory exists
    },
    filename: function (req, file, cb) {
        // Preserve the file extension
        const fileExtension = file.originalname.split('.').pop();
        // Generate a unique filename
        const uniqueFilename = Date.now() + '-' + Math.round(Math.random() * 1E9) + '.' + fileExtension;
        cb(null, uniqueFilename);
    }
});

// Configure upload settings
const upload = multer({
    storage: storage,
    fileFilter: function (req, file, cb) {
        if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only JPEG and PNG files are allowed.'));
        }
    },
    limits: { fileSize: 1024 * 1024 * 5 } // 5 MB file size limit
});

// Middleware for multiple file uploads (up to 5 files)
// var multer = require('multer');
// var multer = require('multer')
// var storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//         cb(null, 'public/images');
//     },
//     filename: function (req, file, cb) {
//         // Preserve the file extension
//         const fileExtension = file.originalname.split('.').pop();
//         // Generate a unique filename
//         const uniqueFilename = Date.now() + '-' + Math.round(Math.random() * 1E9) + '.' + fileExtension;
//         cb(null, uniqueFilename);
//     }
// });

// var upload = multer({
//     storage: storage,
//     fileFilter: function (req, file, cb) {
        
//         if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
//             cb(null, true);
//         } else {
//             cb(new Error('Invalid file type. Only JPEG and PNG files are allowed.'));
//         }
//     }
// });

var categoriesController = require('../Controller/categoriesController')
var dishesController = require('../Controller/dishesController')
const adminController = require('../Controller/adminController');

var maincategoriesController = require('../Controller/mainCategoriesController');
// var stocksController = require('../Controller/stocksController');
const isAuthenticated = require('../Middleware/authMiddleware');
// var CommodityController = require('../Controller/CommodityController');
// const MetalPriceController = require('../Controller/metalpriceController');


// const productController = require('../Controller/productController');

// //login-new
// router.post('/login', adminController.loginUser);
// router.post('/logout',adminController.logout);
// router.get('/isAuthenticated', adminController.checkAuthentication);


//login
router.post('/login', adminController.login);
router.post('/logout', adminController.logout);
router.get('/protected', isAuthenticated, (req, res) => {
  res.status(200).json({ message: 'You have access to this protected route' });
});



//latest
router.post('/postmaincategories', maincategoriesController.createMainCategory);
router.get('/getmaincategories', maincategoriesController.getAllMainCategories);

//Main categoies

// router.post('/postmaincategories', maincategoriesController.postMaincategories);
// router.get('/getmaincategories', maincategoriesController.getMaincategories);
// router.get('/getmaincategoriesbyid/:id', maincategoriesController.getMaincategoriesById);
// router.put('/putmaincategories/:id', maincategoriesController.putMaincategoriesById);
// router.delete('/deletemaincategories/:id', maincategoriesController.deleteMaincategoriesById);

//metalprice
router.get('/update', MetalPriceController.fetchAndStoreMetalPrices);
router.get('/', MetalPriceController.getMetalPrices);

//latest
router.post('/postcategories',categoriesController.createCategory);
router.get('/getcategories',categoriesController.getAllCategories);
// --categories--

// router.post('/postcategories',categoriesController.postCategories);
// router.get('/getcategories',categoriesController.getCategories);
// router.get('/getcategoriesbyid/:id',categoriesController.getCategoriesById);
// router.put('/putcategories/:id',categoriesController.putCategoriesById);
// router.delete('/deletecategories/:id',categoriesController.deleteCategoriesById);


//dishes multiple file
// router.post('/postdishes', upload.array('images', 10), dishesController.postDishes);
// router.get('/getdishes', dishesController.getDishes);
// router.get('/getdishesbyid/:id', dishesController.getDishesById);
// router.put('/putdishes/:id', upload.array('images', 10), dishesController.putDishesById);
// router.delete('/deletedishes/:id', dishesController.deleteDishesById);

//latest

router.post('/postdishes', dishesController.createDish);
router.get('/getdishes', dishesController.getAllDishes);
//dishes single image
// router.post('/postdishes', upload.array('images', 5), dishesController.postDishes);
// // router.post('/postdishes', upload.single('image'),dishesController.postDishes);
// router.get('/getdishes',dishesController.getDishes);
// router.get('/getdishesbyid/:id',dishesController.getDishesById);
// router.put('/putdishes/:id',upload.array('images', 5),dishesController.putDishesById);
// // router.put('/putdishes/:id',upload.single('image'),dishesController.putDishesById);
// router.delete('/deletedishes/:id',dishesController.deleteDishesById);




//FUTURE  stockdetails
router.post('/poststocks',stocksController.postStocks);
// router.get('/getstocks',stocksController.getStocks);
// router.get('/getstocksbyid/:id',stocksController.getStocksById);
// router.put('/putstocks/:id',stocksController.putStocksById);
// router.delete('/deletestocks/:id',stocksController.deleteStocksById);


//price
//FUTURE  stockdetails
router.post('/postcommodity',CommodityController.postCommodity);
router.post('/getcommodity',CommodityController.getCommodity);
router.post('/putcommodities/:id',CommodityController.putCommoditiesById);
router.post('/deletcommodities/:id',CommodityController.deletCommoditiesById);

module.exports = router