const mongoose = require('mongoose');

const CommodityModel = new mongoose.Schema({
        gold: Number,
        silver: Number,
    // metal: String,
    // purity: String,
    // weight: String,
    // unit: Number,
    // sellAED: String,
    // buyAED: String,
    // buyPremium: String,
    // sellPremium: String,
    // // Add more fields as needed
});

module.exports = mongoose.model('Commodity', CommodityModel);

