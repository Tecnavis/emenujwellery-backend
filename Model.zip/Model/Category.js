const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
    name: String,
    mainCategoryId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MainCategory'
    }
});

module.exports = mongoose.model('Category', categorySchema);








// const mongoose = require('mongoose');

// const categoriesSchema = new mongoose.Schema({
//     name: { type: String, required: true },
//     mainCategoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'MainCategory', required: true } // Reference to main category
// });

// module.exports = mongoose.model('Category', categoriesSchema);






// var mongoose = require('mongoose');
// var catagoriesModel = new mongoose.Schema({
//     categories:{type:String, required:true}
//     maincategories:{type:String, required:true}

// })
// var categoriesData = new mongoose.model('categoriesData', catagoriesModel);
// module.exports = categoriesData