// Define MetalPrice model
var mongoose = require('mongoose')

const MetalPriceModel = new mongoose.Schema({
    currency: String,
    price: Number
});
const MetalPrice = new mongoose.model('MetalPrice', MetalPriceModel);
module.exports = MetalPrice

