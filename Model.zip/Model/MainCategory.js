// Model/MaincategoriesModel.js
const mongoose = require('mongoose');

const mainCategorySchema = new mongoose.Schema({
    name: String,
});

module.exports = mongoose.model('MainCategory', mainCategorySchema);


// Check if the model is already defined, if not, define it
// var mongoose = require('mongoose');
// var catagoriesModel = new mongoose.Schema({
//     categories:{type:String, required:true}
//     maincategories:{type:String, required:true}

// })
// var categoriesData = new mongoose.model('categoriesData', catagoriesModel);
// module.exports = categoriesData