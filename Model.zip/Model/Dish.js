const mongoose = require('mongoose');

const dishSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String },
    images: [{ type: String }], // Array of image filenames
    itemNumber: { type: String },
    weight: { type: Number },
    purity: { type: String },
    details: { type: String },
    categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true } // Reference to Category
});

module.exports = mongoose.model('Dish', dishSchema);







// const mongoose = require('mongoose');

// const dishesSchema = new mongoose.Schema({
//     name: { type: String, required: true },
//     price: { type: Number, required: true },
//     description: { type: String },
//     images: [{ type: String }], // Array of image filenames    itemNumber: { type: String },
//     weight: { type: Number },
//     purity: { type: String },
//     details: { type: String },
//     categoryId: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true } // Reference to Category
// });

// module.exports = mongoose.model('Dish', dishesSchema);



//multiple file
// var mongoose = require('mongoose');

// var dishesModel = new mongoose.Schema({
//     price: { type: Number },
//     dishes: { type: String },
//     description: { type: String },
//     categories: { type: String, required: true },
//     images: { type: [String] },
//     Itemnumber: { type: String},
//     weight: { type: String},
//     purity: { type: String},
//     features: { type: String},
//     details: { type: String}
// });

// module.exports = mongoose.model('Dishes', dishesModel);
