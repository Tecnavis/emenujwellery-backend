// var expressAsyncHandler = require('express-async-handler');

const Category = require('../Model/Category');


exports.createCategory = async (req, res) => {
    try {
        const category = await Category.create(req.body);
        res.status(201).json(category);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.getAllCategories = async (req, res) => {
    try {
        const categories = await Category.find();
        res.json(categories);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Implement other CRUD operations for Category (getCategoryById, updateCategory, deleteCategory)




// // using maincatid
// var expressAsyncHandler = require('express-async-handler');
// var category = require('../Model/Category');
// const MainCategory = require('../models/MainCategory');

// // Import the main categories model

// exports.postCategories = expressAsyncHandler(async (req, res) => {
//     const { name, mainCategoryId } = req.body;

//     // Check if mainCategoryId is provided and valid
//     if (!mainCategoryId) {
//         return res.status(400).json({ error: 'mainCategoryId is required' });
//     }

//     try {
//         const mainCategory = await MainCategory.findById(mainCategoryId);
//         if (!mainCategory) {
//             return res.status(404).json({ error: 'Main category not found' });
//         }

//         const newCategory = await category.create({
//             name: name,
//             mainCategoryId: mainCategoryId
//         });

//         res.status(201).json({ message: 'Category posted successfully', data: newCategory });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while posting category', details: err.message });
//     }
// });
// exports.getCategories = expressAsyncHandler(async (req, res) => {
//     const { mainCategoryId } = req.query; // Expecting mainCategoryId as a query parameter

//     let query = {};
//     if (mainCategoryId) {
//         query.mainCategoryId = mainCategoryId;
//     }

//     try {
//         const response = await category.find(query).populate('mainCategoryId', 'mainCategoryName'); // Populate to include main category info
//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while fetching data', details: err.message });
//     }
// });
// exports.getCategoriesById = expressAsyncHandler(async (req, res) => {
//     const { id } = req.params;

//     try {
//         const response = await category.findById(id).populate('mainCategoryId', 'mainCategoryName');
//         if (!response) {
//             return res.status(404).json({ error: 'Category not found' });
//         }
//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while fetching data', details: err.message });
//     }
// });
// exports.putCategoriesById = expressAsyncHandler(async (req, res) => {
//     const { id } = req.params;
//     const { name, mainCategoryId } = req.body;

//     // Validate mainCategoryId if it's provided
//     if (mainCategoryId) {
//         const mainCategory = await MainCategory.findById(mainCategoryId);
//         if (!mainCategory) {
//             return res.status(404).json({ error: 'Main category not found' });
//         }
//     }

//     try {
//         const updateData = await category.findByIdAndUpdate(
//             id, 
//             { $set: { name: name, mainCategoryId: mainCategoryId } }, 
//             { new: true }
//         );

//         if (!updateData) {
//             return res.status(404).json({ error: 'Category not found' });
//         }

//         res.status(200).json({ message: 'Category updated successfully', data: updateData });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'Error while updating data', details: err.message });
//     }
// });
// exports.deleteCategoriesById = expressAsyncHandler(async (req, res) => {
//     const { id } = req.params;

//     try {
//         const response = await category.findByIdAndDelete(id);
//         if (!response) {
//             return res.status(404).json({ error: 'Category not found' });
//         }
//         res.status(200).json({ message: 'Category deleted successfully', data: response });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while deleting data', details: err.message });
//     }
// });




// var asynchandler = require('express-async-handler');
// var category = require('../Model/CategoriesModel');

// exports.postCategories = asynchandler(async (req, res) => {
//     const { categories, maincategories } = req.body;

//     try {
//         const newCategories = await categoriesModel.create({
//             categories: categories,
//             maincategories: maincategories
//         });
//         res.status(200).send('Categories posted successfully');
//         categories: newCategories

//     } catch (err) {
//         console.log(err);
//         res.status(500).send('An error occurred while posting categories');
//     }
// });
// exports.getCategories = async (req, res) => {
//     const search = req.query.search;
//     console.log(search, "the search term"); // Log the search term
//     try {
//         const query = {};
//         if (search) {
//             query.$or = [
//                 { maincategories: { $regex: search, $options: 'i' } }
//             ];
//         }
//         console.log(query, "the query"); // Log the formed query
//         const response = await categoriesModel.find(query);
//         console.log(response, "the response"); // Log the response from the database
//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err); // Log any errors
//         res.status(500).send('An error occurred while fetching data');
//     }
// };


// exports.getCategoriesById = asynchandler(async (req, res) => {
//     const { id } = req.params;
//     console.log(req.params, 'the id is here');
//     try {
//         const response = await categoriesModel.findById(id);
//         res.status(200).json(response);
//     } catch (err) {
//         console.log(err);
//         res.status(500).send('An error occurred while fetching data');
//     }
// });

// exports.putCategoriesById = asynchandler(async (req, res) => {
//     const { id } = req.params;
//     const { categories, maincategories } = req.body;

//     try {
//         const update = {
//             categories: categories,
//             maincategories: maincategories
//         };
//         const updateData = await categoriesModel.findByIdAndUpdate(id, { $set: update }, { new: true });
//         res.status(200).json(updateData);
//     } catch (err) {
//         res.status(500).json({ err: 'error while updating data' });
//     }
// });

// exports.deleteCategoriesById = asynchandler(async (req, res) => {
//     const { id } = req.params;
//     try {
//         const response = await categoriesModel.findByIdAndDelete(id);
//         res.status(200).json(response);
//     } catch (err) {
//         console.log(err);
//         res.status(500).send('An error occurred while deleting data');
//     }
// });









//orginal

// var asynchandler = require('express-async-handler')
// var catagoriesModel = require('../Model/CategoriesModel')


// exports.postCategories = asynchandler(async(req, res)=>{
//     const {categories} = req.body
    
//     try{
//         await catagoriesModel.create({
//             categories:categories
//         })
//         res.status(200).send('Categories posted successfully')
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while posting categories')
//     }
// })

// exports.getCategories = asynchandler(async(req,res)=>{
//     try{
//         const response = await catagoriesModel.find()
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while fetching data')
//     }
// })

// exports.getCategoriesById = asynchandler(async(req,res)=>{
//     const {id} = req.params
//     console.log(req.params, 'the id is here')
//     try{
//         const response = await catagoriesModel.findById(id)
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while fetching data')
//     }
// })

// exports.putCategoriesById = asynchandler(async(req, res)=>{
//     const {id} = req.params;
//     const {categories} = req.body;
   
   

//     try{
    
//         const update = {
//            categories:categories
//         }
//         const updateData = await catagoriesModel.findByIdAndUpdate(id, {$set:update}, {new:true})
//         res.status(200).json(updateData)
       
//     }catch(err){
//         res.status(500).json({err:'error while updating data'})
//     }
// })

// exports.deleteCategoriesById = asynchandler(async(req, res)=>{
//     const {id} = req.params
//     try{
//         const response = await catagoriesModel.findByIdAndDelete(id)
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//     }
// })











