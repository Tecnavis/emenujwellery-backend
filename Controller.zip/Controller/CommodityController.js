
var asynchandler = require('express-async-handler');
const CommodityModel = require('../Model/CommodityModel');

// Fetch all commodities



  exports.getCommodity= async (req, res) => {
    try {
        const commodities = await Commodity.find();
        res.json(commodities);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

// Add a new commodity
exports.postCommodity=  async (req, res) => {
    try {
        const newCommodity = new commodities(req.body);
        await newCommodity.save();
        res.json(newCommodity);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

// Update a commodity
exports.putCommoditiesById= async (req, res) => {
    try {
        const updatedCommodity = await Commodity.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.json(updatedCommodity);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};

// Delete a commodity
exports.deletCommoditiesById= async (req, res) => {
    try {
        await Commodity.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Commodity deleted' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
};
