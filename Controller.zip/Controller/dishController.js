const Dish = require('../Model/Dish');

// Controller functions for Dish model
exports.createDish = async (req, res) => {
    try {
        const dish = await Dish.create(req.body);
        res.status(201).json(dish);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.getAllDishes = async (req, res) => {
    const { mainCategoryName } = req.query;

    try {
        let dishes;
        if (mainCategoryName) {
            dishes = await Dish.find()
                .populate({
                    path: 'categoryId',
                    populate: {
                        path: 'mainCategoryId',
                        match: { name: mainCategoryName }
                    }
                })
                .exec();

            // Filter dishes based on main category name
            dishes = dishes.filter(dish => dish.categoryId.mainCategoryId !== null);
        } else {
            dishes = await Dish.find();
        }

        res.json(dishes);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.updateDish = async (req, res) => {
    const { id } = req.params;
    try {
        const dish = await Dish.findByIdAndUpdate(id, req.body, { new: true });
        if (!dish) {
            return res.status(404).json({ error: 'Dish not found' });
        }
        res.json(dish);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.deleteDish = async (req, res) => {
    const { id } = req.params;
    try {
        const deletedDish = await Dish.findByIdAndDelete(id);
        if (!deletedDish) {
            return res.status(404).json({ error: 'Dish not found' });
        }
        res.json({ message: 'Dish deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Implement other CRUD operations for Dish (getDishById, updateDish, deleteDish)









// const Dish = require('../Model/Dish');
// const Category = require('../Model/Category');
// const upload = require('../Middleware/multer');

// exports.postDishes = (req, res) => {
//     upload(req, res, async function (err) {
//         if (err) {
//             return res.status(400).json({ error: err.message });
//         }

//         const { name, price, description, itemNumber, weight, purity, details, categoryId } = req.body;

//         if (!categoryId) {
//             return res.status(400).json({ error: 'categoryId is required' });
//         }

//         try {
//             const category = await Category.findById(categoryId).populate('mainCategoryId');
//             if (!category) {
//                 return res.status(404).json({ error: 'Category not found' });
//             }

//             const imageFilenames = req.files.map(file => file.filename);

//             const newDish = await Dish.create({
//                 name,
//                 price,
//                 description,
//                 categoryId,
//                 images: imageFilenames,
//                 itemNumber,
//                 weight,
//                 purity,
//                 details
//             });

//             res.status(201).json({
//                 message: 'Dish posted successfully',
//                 dish: newDish
//             });
//         } catch (err) {
//             console.error(err);
//             res.status(500).json({ error: 'An error occurred while posting dish', details: err.message });
//         }
//     });
// };

// exports.getDishes = async (req, res) => {
//     const { mainCategoryId, categoryId } = req.query;

//     try {
//         let query = {};

//         if (mainCategoryId) {
//             const categories = await Category.find({ mainCategoryId });
//             const categoryIds = categories.map(category => category._id);

//             if (categoryId) {
//                 if (categoryIds.includes(categoryId)) {
//                     query.categoryId = categoryId;
//                 } else {
//                     return res.status(400).json({ error: 'Category does not belong to the specified main category' });
//                 }
//             } else {
//                 query.categoryId = { $in: categoryIds };
//             }
//         } else if (categoryId) {
//             query.categoryId = categoryId;
//         }

//         const response = await Dish.find(query).populate({
//             path: 'categoryId',
//             populate: { path: 'mainCategoryId' }
//         });

//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while fetching data', details: err.message });
//     }
// };

// exports.getDishesById= async (req, res) => {
//     const { id } = req.params;

//     try {
//         const response = await Dish.findById(id).populate({
//             path: 'categoryId',
//             populate: { path: 'mainCategoryId' }
//         });

//         if (!response) {
//             return res.status(404).json({ error: 'Dish not found' });
//         }

//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while fetching data', details: err.message });
//     }
// };

// exports.putDishesById = (req, res) => {
//     upload(req, res, async function (err) {
//         if (err) {
//             return res.status(400).json({ error: err.message });
//         }

//         const { id } = req.params;
//         const { name, price, description, categoryId, itemNumber, weight, purity, details } = req.body;

//         if (categoryId) {
//             const category = await Category.findById(categoryId);
//             if (!category) {
//                 return res.status(404).json({ error: 'Category not found' });
//             }
//         }

//         try {
//             const updateData = { name, price, description, categoryId, itemNumber, weight, purity, details };

//             if (req.files.length > 0) {
//                 const imageFilenames = req.files.map(file => file.filename);
//                 updateData.images = imageFilenames;
//             }

//             const updatedDish = await Dish.findByIdAndUpdate(id, { $set: updateData }, { new: true });

//             if (!updatedDish) {
//                 return res.status(404).json({ error: 'Dish not found' });
//             }

//             res.status(200).json({ message: 'Dish updated successfully', data: updatedDish });
//         } catch (err) {
//             console.error(err);
//             res.status(500).json({ error: 'Error while updating data', details: err.message });
//         }
//     });
// };

// exports.deleteDishesById = async (req, res) => {
//     const { id } = req.params;

//     try {
//         const response = await Dish.findByIdAndDelete(id);
//         if (!response) {
//             return res.status(404).json({ error: 'Dish not found' });
//         }
//         res.status(200).json({ message: 'Dish deleted successfully', data: response });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while deleting data', details: err.message });
//     }
// };








// var asynchandler = require('express-async-handler');
// var dishesModel = require('../Model/DishesModel')

// exports.postDishes = asynchandler(async (req, res) => {
//     const { price, dishes, categories, description, Itemnumber, weight, purity, details, maincategories } = req.body;
//     const image = req.file ? req.file.filename : undefined;

//     try {
//         const newDish = await dishesModel.create({
//             price: price,
//             dishes: dishes,
//             description: description,
//             categories: categories,
//             image: image,
//             Itemnumber: Itemnumber,
//             weight: weight,
//             purity: purity,
//             details: details,
//             maincategories: maincategories,
//         });
//         res.status(200).json({
//             message: 'Dishes posted successfully',
//             dish: newDish
//         });
//     } catch (err) {
//         console.log(err);
//         res.status(500).send('An error occurred while posting Dishes');
//     }
// });

// // exports.postDishes = asynchandler(async (req, res) => {
// //     const { price, dishes, categories,description,Itemnumber,weight,purity,features,details,maincategories } = req.body;
// //     const image = req.file ? req.file.filename : undefined;

// //     try {
// //         const newDish = await dishesModel.create({
// //             price: price,
// //             dishes: dishes,
// //             description:description,
// //             categories: categories,
// //             image: image,
// //             Itemnumber:Itemnumber,
// //             weight:weight,
// //             purity:purity,
// //             features:features,
// //             details:details,
// //             maincategories:maincategories,
            
// //         });
// //         res.status(200).json({
// //             message: 'Dishes posted successfully',
// //             dish: newDish
// //         });
// //     } catch (err) {
// //         console.log(err);
// //         res.status(500).send('An error occurred while posting Dishes');
// //     }
// // });


// exports.getDishes = async (req, res) => {
//     const { maincategories, categories } = req.query;
//     console.log(maincategories, "the maincategories");
//     console.log(categories, "the categories");

//     try {
//         const query = {};

//         if (maincategories && categories) {
//             query.$and = [
//                 { maincategories: { $regex: maincategories, $options: 'i' } },
//                 { categories: { $regex: categories, $options: 'i' } }
//             ];
//         } else if (maincategories) {
//             query.maincategories = { $regex: maincategories, $options: 'i' };
//         } else if (categories) {
//             query.categories = { $regex: categories, $options: 'i' };
//         }

//         console.log(query, "the query");
//         const response = await dishesModel.find(query);

//         console.log(response, "the response");
//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err);
//         res.status(500).send('An error occurred while fetching data');
//     }
// };



// // exports.getDishes = async (req, res) => {
// //     const search = req.query.search;
// //     console.log(search, "the search term"); // Log the search term
// //     try {
// //         const query = {};
// //         if (search) {
// //             query.$or = [
// //                 { categories: { $regex: search, $options: 'i' } }
// //             ];
// //         }
// //         console.log(query, "the query"); // Log the formed query
// //         const response = await dishesModel.find(query);
// //         console.log(response, "the response"); // Log the response from the database
// //         res.status(200).json(response);
// //     } catch (err) {
// //         console.error(err); // Log any errors
// //         res.status(500).send('An error occurred while fetching data');
// //     }
// // };



// exports.getDishesById = asynchandler(async(req,res)=>{
//     const {id} = req.params
//     // console.log(req.params, 'the id is here')
//     try{
//         const response = await dishesModel.findById(id)
//         res.status(200).json(response)
        
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while fetching data')
//     }
// })

// exports.putDishesById = asynchandler(async(req, res)=>{
//     const {id} = req.params;
//     const {categories, price, dishes,description,Itemnumber,weight,purity,features,details,maincategories} = req.body;
//     const image = req.file ? req.file.filename : undefined;
//     console.log(req.body)
   

//     try{
    
//         const update = {
//             maincategories:maincategories,
//             categories:categories,
//            price:price,
//            dishes:dishes,
//            description:description,
//            image:image,
//            Itemnumber:Itemnumber,
//            weight:weight,
//            purity:purity,
//            features:features,
//            details:details
//         }
//         const updateData = await dishesModel.findByIdAndUpdate(id, {$set:update}, {new:true})
//         res.status(200).json(updateData)
       
//     }catch(err){
//         res.status(500).json({err:'error while updating data'})
//     }
// })

// exports.deleteDishesById = asynchandler(async(req, res)=>{
//     const {id} = req.params
//     try{
//         const response = await dishesModel.findByIdAndDelete(id)
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//     }
// })



// // var asynchandler = require('express-async-handler');
// // var dishesModel = require('../Model/DishesModel');
// // var multer = require('multer');
// // var upload = multer({ dest: 'uploads/' });

// // exports.postDishes = asynchandler(async (req, res) => {
// //     const { price, dishes, categories, description, Itemnumber, weight, purity, features, details } = req.body;
// //     const images = req.files ? req.files.map(file => file.filename) : [];

// //     try {
// //         const newDish = await dishesModel.create({
// //             price: price,
// //             dishes: dishes,
// //             description: description,
// //             categories: categories,
// //             images: images,
// //             Itemnumber: Itemnumber,
// //             weight: weight,
// //             purity: purity,
// //             features: features,
// //             details: details
// //         });
// //         res.status(200).json({
// //             message: 'Dishes posted successfully',
// //             dish: newDish
// //         });
// //     } catch (err) {
// //         console.log(err);
// //         res.status(500).send('An error occurred while posting Dishes');
// //     }
// // });

// // exports.getDishes = async (req, res) => {
// //     const search = req.query.search;
// //     console.log(search, "the search term");
// //     try {
// //         const query = {};
// //         if (search) {
// //             query.$or = [
// //                 { categories: { $regex: search, $options: 'i' } }
// //             ];
// //         }
// //         console.log(query, "the query");
// //         const response = await dishesModel.find(query);
// //         console.log(response, "the response");
// //         res.status(200).json(response);
// //     } catch (err) {
// //         console.error(err);
// //         res.status(500).send('An error occurred while fetching data');
// //     }
// // };

// // exports.getDishesById = asynchandler(async (req, res) => {
// //     const { id } = req.params;
// //     try {
// //         const response = await dishesModel.findById(id);
// //         res.status(200).json(response);
// //     } catch (err) {
// //         console.log(err);
// //         res.status(500).send('An error occurred while fetching data');
// //     }
// // });

// // exports.putDishesById = asynchandler(async (req, res) => {
// //     const { id } = req.params;
// //     const { categories, price, dishes, description, Itemnumber, weight, purity, features, details } = req.body;
// //     const images = req.files ? req.files.map(file => file.filename) : undefined;

// //     console.log(req.body);

// //     try {
// //         const update = {
// //             categories: categories,
// //             price: price,
// //             dishes: dishes,
// //             description: description,
// //             Itemnumber: Itemnumber,
// //             weight: weight,
// //             purity: purity,
// //             features: features,
// //             details: details,
// //         };

// //         if (images) {
// //             update.images = images;
// //         }

// //         const updateData = await dishesModel.findByIdAndUpdate(id, { $set: update }, { new: true });
// //         res.status(200).json(updateData);
// //     } catch (err) {
// //         res.status(500).json({ err: 'error while updating data' });
// //     }
// // });

// // exports.deleteDishesById = asynchandler(async (req, res) => {
// //     const { id } = req.params;
// //     try {
// //         const response = await dishesModel.findByIdAndDelete(id);
// //         res.status(200).json(response);
// //     } catch (err) {
// //         console.log(err);
// //     }
// // });
