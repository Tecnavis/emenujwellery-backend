const axios = require('axios');
const MetalPrice = require('../Model/MetalpriceModel');

const fetchAndStoreMetalPrices = async () => {
    try {
        const response = await axios.get('https://api.metalpriceapi.com/v1/latest', {
            params: {
                api_key: '4a8f8fa4a941a1adfe60879e295c6078',
                base: 'USD',
                currencies: 'AED,XAU,XAG'
            }
        });

        const metalPrices = response.data.rates;
        const metalPriceData = Object.entries(metalPrices).map(([currency, price]) => ({ currency, price }));
        await MetalPrice.deleteMany();
        await MetalPrice.insertMany(metalPriceData);
        console.log('Metal prices updated successfully');
    } catch (error) {
        console.error('Error fetching metal prices:', error);
    }
};

const getMetalPrices = async (req, res) => {
    try {
        const metalPrices = await MetalPrice.find();
        res.json(metalPrices);
    } catch (error) {
        console.error('Error fetching metal prices:', error);
        res.status(500).json({ message: 'Server Error' });
    }
};

module.exports = { fetchAndStoreMetalPrices, getMetalPrices };
