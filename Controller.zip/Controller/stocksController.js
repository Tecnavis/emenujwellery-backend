//selected dataitems
var asynchandler = require('express-async-handler');
var StocksModel = require('../Model/StocksModel')

exports.postStocks = asynchandler(async (req, res) => {
    const { metaltype,
        code,
        description,
        karat,
        stdpurity,
        makingcharge,
        maincategories,
        categories,
        unit,
        modelcode,
        costcenter,
        type,
        brand,
        design,
        vendor,
        hsn,
        country,
        size,
        color,
        venderref,} = req.body;
    // const image = req.file ? req.file.filename : undefined;

    try {
        const newstock = await StocksModel.create({
            metaltype,
            code,
            description,
            karat,
            stdpurity,
            makingcharge,
            maincategories,
            categories,
            unit,
            modelcode,
            costcenter,
            type,
            brand,
            design,
            vendor,
            hsn,
            country,
            size,
            color,
            venderref,
           
        });
        res.status(200).json({
            message: 'Stocks posted successfully',
            stock: newstock
        });
    } catch (err) {
        console.log(err);
        res.status(500).send('An error occurred while posting Dishes');
    }
});

















//All data 
// var asynchandler = require('express-async-handler');
// var StocksModel = require('../Model/StocksModel')

// exports.postStocks = asynchandler(async (req, res) => {
//     const { metaltype,
//         code,
//         // branch,
//         description,
//         karat,
//         stdpurity,
//         makingcharge,
//         // parent,
//         // otherdescription,
//         maincategories,
//         categories,
//         unit,
//         modelcode,
//         costcenter,
//         type,
//         brand,
//         design,
//         vendor,
//         hsn,
//         // hsmaster,
//         country,
//         size,
//         color,
//         venderref,
//     // price1,
//     // price2,
//     // price3,
//     // price4,
//     // price5,
//     // detailss,
//     // standardcost,
//     // salesdiscount,
//     // maximumstock,
//     // recorderlevel,
//     // recorderquantity,
//     // saleschargeon,
//     // purcost,
//     // saleprice,
//     // seqcode,
//     // location,
//     // createdon,
//     // by,
//     // firsttransaction,
//     // lasttransaction,
//     // mt5ratetype,
//     // inpieces,
//     // createbarcodes,
//     // passpuritydiffrence,
//     // includestoneweight,
//     // askpercentage,
//     // vatonmaking,
//     // avoidalloy,
//     // abcmaster,
//     // asksupplier,
//     // alloyitem,
//     // dustitem,
//     // excludetax,
//     // ozfactor,
//     // fineoz,
//     // packingsize,
//     // defsalepurity,
//     // askweightage,
//     // makingnetwork,
//     // dyestrip,
//     // kundan,
//     // allownegativestock,
//     // blockweightinsale,
//     // allowlesscost,
//     // finisheditem,
//     // excludefromtransfer,
//     // blockinalltransaction,
//     // blockinallreports,
//     // qtyroundoff,
//     // kundanrate,
//     // linksubcode,
//     // stamprate,

//  } = req.body;
//     // const image = req.file ? req.file.filename : undefined;

//     try {
//         const newstock = await StocksModel.create({
//             metaltype,
//             code,
//             // branch,
//             description,
//             karat,
//             stdpurity,
//             makingcharge,
//             // parent,
//             // otherdescription,
//             maincategories,
//             categories,
//             unit,
//             modelcode,
//             costcenter,
//             type,
//             brand,
//             design,
//             vendor,
//             hsn,
//             // hsmaster,
//             country,
//             size,
//             color,
//             venderref,
//             // price1,
//             // price2,
//             // price3,
//             // price4,
//             // price5,
//             // detailss,
//             // standardcost,
//             // salesdiscount,
//             // maximumstock,
//             // recorderlevel,
//             // recorderquantity,
//             // saleschargeon,
//             // purcost,
//             // saleprice,
//             // seqcode,
//             // location,
//             // createdon,
//             // by,
//             // firsttransaction,
//             // lasttransaction,
//             // mt5ratetype,
//             // inpieces,
//             // createbarcodes,
//             // passpuritydiffrence,
//             // includestoneweight,
//             // askpercentage,
//             // vatonmaking,
//             // avoidalloy,
//             // abcmaster,
//             // asksupplier,
//             // alloyitem,
//             // dustitem,
//             // excludetax,
//             // ozfactor,
//             // fineoz,
//             // packingsize,
//             // defsalepurity,
//             // askweightage,
//             // makingnetwork,
//             // dyestrip,
//             // kundan,
//             // allownegativestock,
//             // blockweightinsale,
//             // allowlesscost,
//             // finisheditem,
//             // excludefromtransfer,
//             // blockinalltransaction,
//             // blockinallreports,
//             // qtyroundoff,
//             // kundanrate,
//             // linksubcode,
//             // stamprate,
//         });
//         res.status(200).json({
//             message: 'Stocks posted successfully',
//             dish: newDish
//         });
//     } catch (err) {
//         console.log(err);
//         res.status(500).send('An error occurred while posting Dishes');
//     }
// });

//FUTURE
// exports.getStocks = async (req, res) => {
//     const search = req.query.search;
//     console.log(search, "the search term"); // Log the search term
//     try {
//         const query = {};
//         if (search) {
//             query.$or = [
//                 { categories: { $regex: search, $options: 'i' } }
//             ];
//         }
//         console.log(query, "the query"); // Log the formed query
//         const response = await dishesModel.find(query);
//         console.log(response, "the response"); // Log the response from the database
//         res.status(200).json(response);
//     } catch (err) {
//         console.error(err); // Log any errors
//         res.status(500).send('An error occurred while fetching data');
//     }
// };



// exports.getDishesById = asynchandler(async(req,res)=>{
//     const {id} = req.params
//     // console.log(req.params, 'the id is here')
//     try{
//         const response = await dishesModel.findById(id)
//         res.status(200).json(response)
        
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while fetching data')
//     }
// })

// exports.putDishesById = asynchandler(async(req, res)=>{
//     const {id} = req.params;
//     const {categories, price, dishes,description,Itemnumber,weight,purity,features,details} = req.body;
//     const image = req.file ? req.file.filename : undefined;
//     console.log(req.body)
   

//     try{
    
//         const update = {
//             categories:categories,
//            price:price,
//            dishes:dishes,
//            description:description,
//            image:image,
//            Itemnumber:Itemnumber,
//            weight:weight,
//            purity:purity,
//            features:features,
//            details:details
//         }
//         const updateData = await dishesModel.findByIdAndUpdate(id, {$set:update}, {new:true})
//         res.status(200).json(updateData)
       
//     }catch(err){
//         res.status(500).json({err:'error while updating data'})
//     }
// })

// exports.deleteDishesById = asynchandler(async(req, res)=>{
//     const {id} = req.params
//     try{
//         const response = await dishesModel.findByIdAndDelete(id)
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//     }
// })