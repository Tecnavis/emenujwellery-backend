//latest
const MainCategory = require('../Model/MainCategory');

exports.createMainCategory = async (req, res) => {
    try {
        const mainCategory = await MainCategory.create(req.body);
        res.status(201).json(mainCategory);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.getAllMainCategories = async (req, res) => {
    try {
        const mainCategories = await MainCategory.find();
        res.json(mainCategories);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


// //using id for items

// // POST Main Categories
// // POST Main Categories
// const asyncHandler = require('express-async-handler');
// const MainCategory = require('../Model/MaincategoriesModel');

// exports.postMaincategories = asyncHandler(async (req, res) => {
//     const { name } = req.body;

//     try {
//         const newCategory = await MainCategory.create({ name });
//         res.status(201).json({ message: 'MainCategory posted successfully', data: newCategory });
//     } catch (err) {
//         console.log(err);
//         res.status(500).json({ error: 'An error occurred while posting category' });
//     }
// });

// // GET All Main Categories
// exports.getMaincategories = asyncHandler(async (req, res) => {
//     try {
//         const categories = await MainCategory.find();
//         res.status(200).json(categories);
//     } catch (err) {
//         console.log(err);
//         res.status(500).json({ error: 'An error occurred while fetching data' });
//     }
// });

// // GET Main Categories by ID
// exports.getMaincategoriesById = asyncHandler(async (req, res) => {
//     const { id } = req.params;

//     try {
//         const category = await MainCategory.findById(id);
//         if (category) {
//             res.status(200).json(category);
//         } else {
//             res.status(404).json({ error: 'Category not found' });
//         }
//     } catch (err) {
//         console.log(err);
//         res.status(500).json({ error: 'An error occurred while fetching data' });
//     }
// });
// // GET Main Categories by ID


// // PUT (Update) Main Categories by ID
// // PUT (Update) Main Categories by ID
// exports.putMaincategoriesById = asyncHandler(async (req, res) => {
//     const { id } = req.params;
//     const { name } = req.body; // Use camelCase consistently

//     if (!name) {
//         return res.status(400).json({ error: 'Name is required for updating main category' });
//     }

//     try {
//         const updateData = await MainCategory.findByIdAndUpdate(id, { $set: { name } }, { new: true });
//         if (!updateData) {
//             return res.status(404).json({ error: 'Main category not found' });
//         }
//         res.status(200).json({ message: 'Main category updated successfully', data: updateData });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'Error while updating data', details: err.message });
//     }
// });

// // DELETE Main Categories by ID
// exports.deleteMaincategoriesById = expressAsyncHandler(async (req, res) => {
//     const { id } = req.params;

//     try {
//         const response = await MainCategory.findByIdAndDelete(id);
//         if (!response) {
//             return res.status(404).json({ error: 'Main category not found' });
//         }
//         res.status(200).json({ message: 'Main category deleted successfully', data: response });
//     } catch (err) {
//         console.error(err);
//         res.status(500).json({ error: 'An error occurred while deleting data', details: err.message });
//     }
// });
















// var asynchandler = require('express-async-handler')
// var mainCategoryModel  = require('../Model/MaincategoriesModel')


// exports.postMaincategories = asynchandler(async(req, res)=>{
//     const {maincategories} = req.body
    
//     try{
//         await maincategoriesModel.create({
//             maincategories:maincategories
//         })
//         res.status(200).send('MainCategories posted successfully')
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while posting categories')
//     }
// })

// exports.getMaincategories = asynchandler(async(req,res)=>{
//     try{
//         const response = await maincategoriesModel.find()
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while fetching data')
//     }
// })

// exports.getMaincategoriesById = asynchandler(async(req,res)=>{
//     const {id} = req.params
//     console.log(req.params, 'the id is here')
//     try{
//         const response = await maincategoriesModel.findById(id)
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//         res.status(500).send('An error occured while fetching data')
//     }
// })

// // exports.putMaincategoriesById = asynchandler(async(req, res)=>{
// //     const {id} = req.params;
// //     const {Maincategories} = req.body;
   
// //     try{
    
// //         const update = {
// //             Maincategories:Maincategories
// //         }
// //         const updateData = await maincategoriesModel.findByIdAndUpdate(id, {$set:update}, {new:true})
// //         res.status(200).json(updateData)
       
// //     }catch(err){
// //         res.status(500).json({err:'error while updating data'})
// //     }
// // })

// exports.putMaincategoriesById = asynchandler(async (req, res) => {
//     const { id } = req.params;
//     const { maincategories } = req.body; // Use lowercase consistently

//     try {
//         const update = { maincategories }; // Use lowercase consistently
//         const updateData = await maincategoriesModel.findByIdAndUpdate(id, { $set: update }, { new: true });
//         res.status(200).json(updateData);
//     } catch (err) {
//         console.log(err);
//         res.status(500).json({ err: 'Error while updating data' });
//     }
// });


// exports.deleteMaincategoriesById = asynchandler(async(req, res)=>{
//     const {id} = req.params
//     try{
//         const response = await maincategoriesModel.findByIdAndDelete(id)
//         res.status(200).json(response)
//     }catch(err){
//         console.log(err)
//     }
// })